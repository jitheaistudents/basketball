import { useEffect, useRef, useState } from "react";

const WORLD_WIDTH = 1000;
const WORLD_HEIGHT = 560;
const FLOOR_Y = 482;
const CEILING_Y = 28;
const SCORE_TO_WIN = 7;
const STORAGE_KEY = "neon-rim-rumble-records-v1";
const LEFT_HOOP = {
  rimX: 176,
  rimY: 220,
  boardX: 114,
  boardY: 146,
  boardW: 16,
  boardH: 136,
};
const RIGHT_HOOP = {
  rimX: 824,
  rimY: 220,
  boardX: 870,
  boardY: 146,
  boardW: 16,
  boardH: 136,
};

type Phase = "start" | "playing" | "paused" | "round" | "gameover";
type Side = 1 | 2;
type Shape = "circle" | "spark" | "star";

type Modifier = {
  id: string;
  name: string;
  blurb: string;
  gravity: number;
  speed: number;
  jump: number;
  ballBounce: number;
  catchBonus: number;
  wind: number;
  ballRadius: number;
};

type Player = {
  id: Side;
  name: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  dir: -1 | 1;
  color: string;
  accent: string;
  onGround: boolean;
  coyote: number;
  actionCooldown: number;
  stun: number;
  flash: number;
  squash: number;
  dunkTimer: number;
  hasBall: boolean;
};

type BallTrailPoint = {
  x: number;
  y: number;
  life: number;
};

type Ball = {
  x: number;
  y: number;
  prevX: number;
  prevY: number;
  vx: number;
  vy: number;
  r: number;
  heldBy: Side | null;
  catchCooldown: number;
  scoreCooldown: number;
  spin: number;
  trail: BallTrailPoint[];
  lastTouched: Side | null;
  flash: number;
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  shape: Shape;
};

type GameState = {
  phase: Phase;
  score1: number;
  score2: number;
  players: [Player, Player];
  ball: Ball;
  particles: Particle[];
  activeModifier: Modifier;
  roundTimer: number;
  shake: number;
  elapsed: number;
  winner: Side | null;
  roundMessage: string;
};

type MatchRecord = {
  winner: string;
  score: string;
  timeMs: number;
  modifier: string;
  createdAt: number;
};

type InputState = {
  left: boolean;
  right: boolean;
  jump: boolean;
  action: boolean;
  jumpPressed: boolean;
  actionPressed: boolean;
};

type HudState = {
  phase: Phase;
  score1: number;
  score2: number;
  modifierName: string;
  modifierBlurb: string;
  roundMessage: string;
  winnerText: string;
};

type PhysicsBody = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
};

const MODIFIERS: Modifier[] = [
  {
    id: "moon-ball",
    name: "Moon Ball",
    blurb: "Floatier jumps and extra hang-time.",
    gravity: 0.76,
    speed: 1,
    jump: 1.1,
    ballBounce: 0.88,
    catchBonus: 4,
    wind: 0,
    ballRadius: 14,
  },
  {
    id: "turbo-soles",
    name: "Turbo Soles",
    blurb: "Players burst faster and recover quicker.",
    gravity: 1,
    speed: 1.16,
    jump: 1,
    ballBounce: 0.84,
    catchBonus: 0,
    wind: 0,
    ballRadius: 14,
  },
  {
    id: "super-bounce",
    name: "Super Bounce",
    blurb: "The ball ricochets like an arcade pinball.",
    gravity: 1,
    speed: 1,
    jump: 1,
    ballBounce: 1.04,
    catchBonus: 2,
    wind: 0,
    ballRadius: 14,
  },
  {
    id: "magnet-hands",
    name: "Magnet Hands",
    blurb: "Loose balls are easier to snag and strip.",
    gravity: 1,
    speed: 1,
    jump: 1,
    ballBounce: 0.84,
    catchBonus: 18,
    wind: 0,
    ballRadius: 14,
  },
  {
    id: "chaos-wind",
    name: "Chaos Wind",
    blurb: "Shots drift just enough to stay silly.",
    gravity: 1,
    speed: 1,
    jump: 1,
    ballBounce: 0.84,
    catchBonus: 0,
    wind: 120,
    ballRadius: 14,
  },
  {
    id: "mini-ball",
    name: "Mini Ball",
    blurb: "Smaller ball, quicker snaps, tighter steals.",
    gravity: 1,
    speed: 1.04,
    jump: 1,
    ballBounce: 0.9,
    catchBonus: 8,
    wind: 0,
    ballRadius: 11,
  },
];

const CONTROL_HINTS = {
  p1: "P1  A / D move   W jump   F act",
  p2: "P2  ← / → move   ↑ jump   / act",
};

function clamp(value: number, min: number, max: number) {
  return Math.max(min, Math.min(max, value));
}

function lerp(from: number, to: number, alpha: number) {
  return from + (to - from) * clamp(alpha, 0, 1);
}

function distance(x1: number, y1: number, x2: number, y2: number) {
  return Math.hypot(x2 - x1, y2 - y1);
}

function roundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

function formatTime(timeMs: number) {
  const totalCentiseconds = Math.floor(timeMs / 10);
  const minutes = Math.floor(totalCentiseconds / 6000);
  const seconds = Math.floor((totalCentiseconds % 6000) / 100);
  const centiseconds = totalCentiseconds % 100;
  return `${minutes}:${seconds.toString().padStart(2, "0")}.${centiseconds
    .toString()
    .padStart(2, "0")}`;
}

function createInputState(): InputState {
  return {
    left: false,
    right: false,
    jump: false,
    action: false,
    jumpPressed: false,
    actionPressed: false,
  };
}

function createPlayer(id: Side): Player {
  const left = id === 1;
  return {
    id,
    name: left ? "Player 1" : "Player 2",
    x: left ? 232 : 768,
    y: FLOOR_Y - 28,
    vx: 0,
    vy: 0,
    r: 28,
    dir: left ? 1 : -1,
    color: left ? "#8b5cf6" : "#22d3ee",
    accent: left ? "#f59e0b" : "#fb7185",
    onGround: true,
    coyote: 0.12,
    actionCooldown: 0,
    stun: 0,
    flash: 0,
    squash: 0,
    dunkTimer: 0,
    hasBall: false,
  };
}

function createBall(modifier: Modifier): Ball {
  const x = WORLD_WIDTH / 2;
  const y = 154;
  return {
    x,
    y,
    prevX: x,
    prevY: y,
    vx: (Math.random() - 0.5) * 70,
    vy: -35,
    r: modifier.ballRadius,
    heldBy: null,
    catchCooldown: 0.28,
    scoreCooldown: 0.18,
    spin: 0,
    trail: [],
    lastTouched: null,
    flash: 0,
  };
}

function pickModifier(previousId?: string) {
  const pool = MODIFIERS.filter((modifier) => modifier.id !== previousId);
  return pool[Math.floor(Math.random() * pool.length)] ?? MODIFIERS[0];
}

function createInitialGame(): GameState {
  const modifier = pickModifier();
  return {
    phase: "start",
    score1: 0,
    score2: 0,
    players: [createPlayer(1), createPlayer(2)],
    ball: createBall(modifier),
    particles: [],
    activeModifier: modifier,
    roundTimer: 0,
    shake: 0,
    elapsed: 0,
    winner: null,
    roundMessage: `${modifier.name} is loaded.`,
  };
}

function makeHudState(game: GameState): HudState {
  return {
    phase: game.phase,
    score1: game.score1,
    score2: game.score2,
    modifierName: game.activeModifier.name,
    modifierBlurb: game.activeModifier.blurb,
    roundMessage: game.roundMessage,
    winnerText: game.winner ? `Player ${game.winner} wins!` : "",
  };
}

function loadHighScores(): MatchRecord[] {
  if (typeof window === "undefined") {
    return [];
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }

    const parsed = JSON.parse(raw) as MatchRecord[];
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed
      .filter(
        (entry) =>
          typeof entry?.winner === "string" &&
          typeof entry?.score === "string" &&
          typeof entry?.timeMs === "number" &&
          typeof entry?.modifier === "string" &&
          typeof entry?.createdAt === "number",
      )
      .sort((a, b) => a.timeMs - b.timeMs)
      .slice(0, 8);
  } catch {
    return [];
  }
}

function saveHighScores(entries: MatchRecord[]) {
  if (typeof window === "undefined") {
    return;
  }

  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(entries.slice(0, 8)));
}

function bodyRectCollision(body: PhysicsBody, rect: { x: number; y: number; w: number; h: number }, bounce: number) {
  const closestX = clamp(body.x, rect.x, rect.x + rect.w);
  const closestY = clamp(body.y, rect.y, rect.y + rect.h);
  const dx = body.x - closestX;
  const dy = body.y - closestY;
  const distanceSq = dx * dx + dy * dy;

  if (distanceSq >= body.r * body.r) {
    return false;
  }

  const dist = Math.sqrt(distanceSq) || 0.0001;
  const overlap = body.r - dist;
  const nx = dist === 0 ? (body.x < rect.x + rect.w / 2 ? -1 : 1) : dx / dist;
  const ny = dist === 0 ? (body.y < rect.y + rect.h / 2 ? -1 : 1) : dy / dist;

  body.x += nx * overlap;
  body.y += ny * overlap;

  const velocityAlongNormal = body.vx * nx + body.vy * ny;
  if (velocityAlongNormal < 0) {
    body.vx -= (1 + bounce) * velocityAlongNormal * nx;
    body.vy -= (1 + bounce) * velocityAlongNormal * ny;
  }

  return true;
}

function bodyCircleCollision(body: PhysicsBody, cx: number, cy: number, radius: number, bounce: number) {
  const dx = body.x - cx;
  const dy = body.y - cy;
  const dist = Math.hypot(dx, dy) || 0.0001;
  const target = body.r + radius;

  if (dist >= target) {
    return false;
  }

  const nx = dx / dist;
  const ny = dy / dist;
  const overlap = target - dist;
  body.x += nx * overlap;
  body.y += ny * overlap;

  const velocityAlongNormal = body.vx * nx + body.vy * ny;
  if (velocityAlongNormal < 0) {
    body.vx -= (1 + bounce) * velocityAlongNormal * nx;
    body.vy -= (1 + bounce) * velocityAlongNormal * ny;
  }

  return true;
}

function ControlButton({
  active,
  label,
  caption,
  hue,
  onActiveChange,
}: {
  active: boolean;
  label: string;
  caption: string;
  hue: "violet" | "cyan";
  onActiveChange: (active: boolean) => void;
}) {
  const tintClass =
    hue === "violet"
      ? active
        ? "from-violet-400 via-fuchsia-400 to-amber-300 text-slate-950"
        : "from-violet-500/50 via-fuchsia-500/40 to-amber-400/30 text-white"
      : active
        ? "from-cyan-300 via-sky-300 to-pink-300 text-slate-950"
        : "from-cyan-500/50 via-sky-500/40 to-pink-400/30 text-white";

  return (
    <button
      type="button"
      className={`game-control touch-none select-none rounded-[1.65rem] border border-white/15 bg-gradient-to-br px-3 py-3 shadow-[0_20px_45px_rgba(8,12,30,0.35)] transition duration-100 ${tintClass} ${
        active ? "scale-[0.97] ring-2 ring-white/40" : "hover:scale-[1.01]"
      }`}
      onContextMenu={(event) => event.preventDefault()}
      onPointerDown={(event) => {
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        onActiveChange(true);
      }}
      onPointerUp={() => onActiveChange(false)}
      onPointerCancel={() => onActiveChange(false)}
      onPointerLeave={(event) => {
        if (event.buttons === 0) {
          onActiveChange(false);
        }
      }}
    >
      <span className="block text-2xl font-black leading-none sm:text-3xl">{label}</span>
      <span className="mt-1 block text-[10px] font-semibold uppercase tracking-[0.25em] opacity-80 sm:text-[11px]">
        {caption}
      </span>
    </button>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const frameRef = useRef<number | null>(null);
  const lastTimeRef = useRef(0);
  const viewportRef = useRef({ width: 0, height: 0, dpr: 1 });
  const gameRef = useRef<GameState>(createInitialGame());
  const inputsRef = useRef({ p1: createInputState(), p2: createInputState() });
  const [hud, setHud] = useState<HudState>(() => makeHudState(gameRef.current));
  const [highScores, setHighScores] = useState<MatchRecord[]>([]);
  const [touchPressed, setTouchPressed] = useState<Record<string, boolean>>({});
  const [freshRecord, setFreshRecord] = useState(false);

  const syncHud = (game: GameState) => {
    setHud(makeHudState(game));
  };

  const clearInputs = () => {
    inputsRef.current.p1 = createInputState();
    inputsRef.current.p2 = createInputState();
    setTouchPressed({});
  };

  const setControlState = (
    playerKey: "p1" | "p2",
    control: "left" | "right" | "jump" | "action",
    active: boolean,
  ) => {
    const input = inputsRef.current[playerKey];

    if (control === "jump" && active && !input.jump) {
      input.jumpPressed = true;
    }

    if (control === "action" && active && !input.action) {
      input.actionPressed = true;
    }

    input[control] = active;
  };

  const pushBurst = (
    game: GameState,
    x: number,
    y: number,
    color: string,
    count: number,
    speedMin = 40,
    speedMax = 240,
    life = 0.55,
    spread = Math.PI * 2,
    angleStart = -Math.PI,
    shape: Shape = "circle",
  ) => {
    for (let index = 0; index < count; index += 1) {
      const angle = angleStart + Math.random() * spread;
      const speed = speedMin + Math.random() * (speedMax - speedMin);
      game.particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: life * (0.75 + Math.random() * 0.5),
        maxLife: life,
        size: 3 + Math.random() * 6,
        color,
        shape,
      });
    }
  };

  const getHoopForSide = (side: Side) => (side === 1 ? RIGHT_HOOP : LEFT_HOOP);

  const setBallHolder = (game: GameState, side: Side | null) => {
    game.ball.heldBy = side;
    game.players[0].hasBall = side === 1;
    game.players[1].hasBall = side === 2;
  };

  const startMatch = () => {
    clearInputs();
    setFreshRecord(false);
    const game = gameRef.current;
    game.score1 = 0;
    game.score2 = 0;
    game.elapsed = 0;
    game.winner = null;
    game.phase = "playing";
    game.players = [createPlayer(1), createPlayer(2)];
    game.activeModifier = pickModifier();
    game.ball = createBall(game.activeModifier);
    game.particles = [];
    game.roundTimer = 0;
    game.roundMessage = `${game.activeModifier.name} • ${game.activeModifier.blurb}`;
    game.shake = 10;
    syncHud(game);
  };

  const saveMatchRecord = (game: GameState, winner: Side) => {
    const newEntry: MatchRecord = {
      winner: winner === 1 ? "Player 1" : "Player 2",
      score: `${game.score1}-${game.score2}`,
      timeMs: Math.round(game.elapsed * 1000),
      modifier: game.activeModifier.name,
      createdAt: Date.now(),
    };

    setHighScores((current) => {
      const merged = [...current, newEntry].sort((a, b) => a.timeMs - b.timeMs).slice(0, 8);
      saveHighScores(merged);
      setFreshRecord(merged[0]?.createdAt === newEntry.createdAt);
      return merged;
    });
  };

  const scorePoint = (game: GameState, scorer: Side, message?: string) => {
    const hoop = getHoopForSide(scorer);
    if (scorer === 1) {
      game.score1 += 1;
    } else {
      game.score2 += 1;
    }

    game.shake = 20;
    pushBurst(game, hoop.rimX, hoop.rimY - 8, scorer === 1 ? "#f59e0b" : "#67e8f9", 22, 50, 340, 0.8);
    pushBurst(game, hoop.rimX, hoop.rimY + 10, "#ffffff", 14, 60, 280, 0.55, Math.PI, 0, "star");
    game.roundMessage =
      message ?? `${scorer === 1 ? "Player 1" : "Player 2"} scores! ${game.score1}-${game.score2}`;

    if (game.score1 >= SCORE_TO_WIN || game.score2 >= SCORE_TO_WIN) {
      game.phase = "gameover";
      game.winner = scorer;
      clearInputs();
      saveMatchRecord(game, scorer);
      syncHud(game);
      return;
    }

    game.players = [createPlayer(1), createPlayer(2)];
    game.activeModifier = pickModifier(game.activeModifier.id);
    game.ball = createBall(game.activeModifier);
    game.phase = "round";
    game.roundTimer = 1.12;
    game.roundMessage = `${game.roundMessage}  •  ${game.activeModifier.name}`;
    syncHud(game);
  };

  const shootBall = (game: GameState, player: Player) => {
    const ball = game.ball;
    const modifier = game.activeModifier;
    const targetHoop = getHoopForSide(player.id);
    const startX = player.x + player.dir * 24;
    const startY = player.y - 28;
    const targetX = targetHoop.rimX + (Math.random() - 0.5) * 10;
    const targetY = targetHoop.rimY - 14;
    const gravity = 980 * modifier.gravity;
    const dx = targetX - startX;
    const dy = targetY - startY;
    const flightTime = clamp(0.46 + Math.abs(dx) / 780, 0.48, 0.86);
    const vx = dx / flightTime + player.vx * 0.34;
    const vy = (dy - 0.5 * gravity * flightTime * flightTime) / flightTime + player.vy * 0.16;

    setBallHolder(game, null);
    ball.x = startX;
    ball.y = startY;
    ball.prevX = startX;
    ball.prevY = startY;
    ball.vx = vx;
    ball.vy = vy;
    ball.spin = player.dir * 18;
    ball.flash = 0.22;
    ball.catchCooldown = 0.26;
    ball.scoreCooldown = 0.12;
    ball.lastTouched = player.id;
    ball.trail = [];
    player.actionCooldown = 0.32;
    player.flash = 0.16;
    player.vx -= player.dir * 35;
    game.shake = Math.max(game.shake, 6);
    pushBurst(game, startX, startY, player.accent, 10, 30, 180, 0.35, Math.PI * 0.8, player.dir === 1 ? -1.1 : -2.1);
  };

  const attemptDunk = (game: GameState, player: Player) => {
    const hoop = getHoopForSide(player.id);
    const closeEnough = Math.abs(player.x - hoop.rimX) < 118;
    const highEnough = player.y < hoop.rimY + 88;
    if (!player.onGround && closeEnough && highEnough) {
      player.dunkTimer = 0.18;
      player.actionCooldown = 0.55;
      player.flash = 0.22;
      game.shake = Math.max(game.shake, 10);
      pushBurst(game, player.x, player.y - 18, "#fde68a", 12, 50, 180, 0.36);
      return true;
    }

    return false;
  };

  const catchLooseBall = (game: GameState, player: Player) => {
    const ball = game.ball;
    setBallHolder(game, player.id);
    ball.catchCooldown = 0.14;
    ball.scoreCooldown = 0.14;
    ball.lastTouched = player.id;
    ball.vx = player.vx;
    ball.vy = player.vy;
    ball.spin = 0;
    player.actionCooldown = 0.16;
    player.flash = 0.12;
    game.shake = Math.max(game.shake, 4);
    pushBurst(game, ball.x, ball.y, "#ffffff", 6, 20, 120, 0.22);
  };

  const swatBall = (game: GameState, player: Player) => {
    const ball = game.ball;
    const direction = Math.sign(ball.x - player.x) || player.dir;
    ball.vx = direction * 310 + player.vx * 0.22;
    ball.vy = Math.min(ball.vy, -220) - 160;
    ball.spin = direction * 24;
    ball.catchCooldown = 0.2;
    ball.scoreCooldown = 0.14;
    ball.lastTouched = player.id;
    player.actionCooldown = 0.24;
    player.flash = 0.16;
    game.shake = Math.max(game.shake, 8);
    pushBurst(game, ball.x, ball.y, "#fef08a", 12, 60, 260, 0.34, Math.PI * 1.2, direction === 1 ? -1.3 : -2.1, "spark");
  };

  const stealBall = (game: GameState, player: Player, opponent: Player) => {
    const ball = game.ball;
    setBallHolder(game, player.id);
    ball.catchCooldown = 0.16;
    ball.scoreCooldown = 0.14;
    ball.lastTouched = player.id;
    player.actionCooldown = 0.28;
    player.flash = 0.18;
    opponent.stun = 0.14;
    opponent.flash = 0.18;
    opponent.vx += player.id === 1 ? 55 : -55;
    game.shake = Math.max(game.shake, 10);
    pushBurst(game, (player.x + opponent.x) * 0.5, (player.y + opponent.y) * 0.5 - 18, "#fb7185", 14, 40, 220, 0.4, Math.PI * 2, -Math.PI, "spark");
  };

  const performAction = (game: GameState, player: Player) => {
    const opponent = player.id === 1 ? game.players[1] : game.players[0];
    const ball = game.ball;
    const catchRadius = 52 + game.activeModifier.catchBonus;

    if (ball.heldBy === player.id) {
      if (attemptDunk(game, player)) {
        return;
      }
      shootBall(game, player);
      return;
    }

    if (
      ball.heldBy === opponent.id &&
      opponent.dunkTimer <= 0 &&
      distance(player.x, player.y, opponent.x, opponent.y) < 78 + game.activeModifier.catchBonus
    ) {
      stealBall(game, player, opponent);
      return;
    }

    if (
      ball.heldBy === null &&
      ball.catchCooldown <= 0 &&
      distance(player.x, player.y - 18, ball.x, ball.y) < catchRadius &&
      Math.hypot(ball.vx, ball.vy) < 450
    ) {
      catchLooseBall(game, player);
      return;
    }

    if (ball.heldBy === null && distance(player.x, player.y - 18, ball.x, ball.y) < 86 + game.activeModifier.catchBonus) {
      swatBall(game, player);
      return;
    }

    player.actionCooldown = 0.14;
  };

  const collidePlayers = (playerA: Player, playerB: Player) => {
    const dx = playerB.x - playerA.x;
    const dy = playerB.y - playerA.y;
    const dist = Math.hypot(dx, dy) || 0.0001;
    const minDistance = playerA.r + playerB.r - 4;
    if (dist >= minDistance) {
      return;
    }

    const nx = dx / dist;
    const ny = dy / dist;
    const overlap = minDistance - dist;
    playerA.x -= nx * overlap * 0.5;
    playerA.y -= ny * overlap * 0.5;
    playerB.x += nx * overlap * 0.5;
    playerB.y += ny * overlap * 0.5;

    const relativeVelocityX = playerB.vx - playerA.vx;
    const relativeVelocityY = playerB.vy - playerA.vy;
    const separatingSpeed = relativeVelocityX * nx + relativeVelocityY * ny;

    if (separatingSpeed < 0) {
      const impulse = (-(1 + 0.52) * separatingSpeed) / 2;
      playerA.vx -= impulse * nx;
      playerA.vy -= impulse * ny;
      playerB.vx += impulse * nx;
      playerB.vy += impulse * ny;
    }
  };

  const resolveHoopCollisions = (body: PhysicsBody, bounce: number) => {
    const boards = [LEFT_HOOP, RIGHT_HOOP];
    boards.forEach((hoop) => {
      bodyRectCollision(
        body,
        {
          x: hoop.boardX,
          y: hoop.boardY,
          w: hoop.boardW,
          h: hoop.boardH,
        },
        bounce,
      );
      bodyCircleCollision(body, hoop.rimX - 24, hoop.rimY, 8, bounce);
      bodyCircleCollision(body, hoop.rimX + 24, hoop.rimY, 8, bounce);
    });
  };

  const updatePlayer = (game: GameState, player: Player, input: InputState, dt: number) => {
    const modifier = game.activeModifier;
    const wasOnGround = player.onGround;
    player.actionCooldown = Math.max(0, player.actionCooldown - dt);
    player.stun = Math.max(0, player.stun - dt);
    player.flash = Math.max(0, player.flash - dt);
    player.coyote = Math.max(0, player.coyote - dt);
    player.squash = Math.max(0, player.squash - dt * 4.5);

    if (player.dunkTimer > 0) {
      const hoop = getHoopForSide(player.id);
      player.dunkTimer -= dt;
      player.x = lerp(player.x, hoop.rimX + (player.id === 1 ? -18 : 18), dt * 16);
      player.y = lerp(player.y, hoop.rimY - 8, dt * 16);
      player.vx *= 0.78;
      player.vy *= 0.78;
      if (player.dunkTimer <= 0) {
        setBallHolder(game, null);
        game.ball.x = hoop.rimX;
        game.ball.y = hoop.rimY + 10;
        game.ball.prevX = hoop.rimX;
        game.ball.prevY = hoop.rimY - 8;
        game.ball.vx = player.id === 1 ? 40 : -40;
        game.ball.vy = 120;
        game.ball.lastTouched = player.id;
        scorePoint(game, player.id, `${player.name} detonates a dunk!`);
      }
      return;
    }

    let move = 0;
    if (player.stun <= 0) {
      move = (input.left ? -1 : 0) + (input.right ? 1 : 0);
    }

    const acceleration = player.onGround ? 2050 * modifier.speed : 1380 * modifier.speed;
    const maxSpeed = 335 * modifier.speed;

    if (move !== 0) {
      player.vx += move * acceleration * dt;
      player.dir = move > 0 ? 1 : -1;
    } else {
      player.vx *= player.onGround ? 0.82 : 0.986;
    }

    player.vx = clamp(player.vx, -maxSpeed, maxSpeed);

    if (player.stun <= 0 && input.jumpPressed && (player.onGround || player.coyote > 0)) {
      player.vy = -510 * modifier.jump;
      player.onGround = false;
      player.coyote = 0;
      player.squash = 1;
      pushBurst(game, player.x, FLOOR_Y + 2, "rgba(255,255,255,0.9)", 8, 20, 140, 0.32, Math.PI, 0);
      game.shake = Math.max(game.shake, 4);
    }

    if (player.stun <= 0 && input.actionPressed && player.actionCooldown <= 0) {
      performAction(game, player);
    }

    player.vy += 980 * modifier.gravity * dt;
    player.x += player.vx * dt;
    player.y += player.vy * dt;
    player.onGround = false;

    if (player.x - player.r < 24) {
      player.x = 24 + player.r;
      player.vx = Math.abs(player.vx) * 0.25;
    }

    if (player.x + player.r > WORLD_WIDTH - 24) {
      player.x = WORLD_WIDTH - 24 - player.r;
      player.vx = -Math.abs(player.vx) * 0.25;
    }

    if (player.y - player.r < CEILING_Y) {
      player.y = CEILING_Y + player.r;
      if (player.vy < 0) {
        player.vy *= -0.18;
      }
    }

    resolveHoopCollisions(player, 0.18);

    if (player.y + player.r > FLOOR_Y) {
      const impact = player.vy;
      player.y = FLOOR_Y - player.r;
      if (impact > 220) {
        pushBurst(game, player.x, FLOOR_Y + 2, player.accent, 10, 30, 170, 0.3, Math.PI, 0);
        player.squash = 1;
        game.shake = Math.max(game.shake, clamp(impact / 75, 2, 8));
      }
      player.vy = impact > 180 ? -impact * 0.1 : 0;
      player.onGround = true;
      player.coyote = 0.1;
    }

    if (!wasOnGround && player.onGround) {
      player.flash = Math.max(player.flash, 0.08);
    }
  };

  const updateHeldBall = (game: GameState, dt: number) => {
    const carrier = game.ball.heldBy === 1 ? game.players[0] : game.ball.heldBy === 2 ? game.players[1] : null;
    if (!carrier) {
      return;
    }

    game.ball.catchCooldown = Math.max(0, game.ball.catchCooldown - dt);
    game.ball.scoreCooldown = Math.max(0, game.ball.scoreCooldown - dt);
    game.ball.flash = Math.max(0, game.ball.flash - dt);
    game.ball.prevX = game.ball.x;
    game.ball.prevY = game.ball.y;
    game.ball.x = carrier.x + carrier.dir * 25;
    game.ball.y = carrier.y - 28 + Math.sin(game.elapsed * 10) * 2;
    game.ball.vx = carrier.vx;
    game.ball.vy = carrier.vy;
    game.ball.r = game.activeModifier.ballRadius;
    game.ball.spin *= 0.9;
    game.ball.trail = [];
  };

  const updateLooseBall = (game: GameState, dt: number) => {
    const ball = game.ball;
    ball.catchCooldown = Math.max(0, ball.catchCooldown - dt);
    ball.scoreCooldown = Math.max(0, ball.scoreCooldown - dt);
    ball.flash = Math.max(0, ball.flash - dt);
    ball.prevX = ball.x;
    ball.prevY = ball.y;
    ball.r = game.activeModifier.ballRadius;
    ball.vx += Math.sin(game.elapsed * 3 + ball.y * 0.02) * game.activeModifier.wind * dt;
    ball.vy += 980 * game.activeModifier.gravity * dt;
    ball.x += ball.vx * dt;
    ball.y += ball.vy * dt;
    ball.spin += ball.vx * 0.0015;

    if (ball.y + ball.r > FLOOR_Y) {
      ball.y = FLOOR_Y - ball.r;
      if (Math.abs(ball.vy) > 60) {
        const impact = Math.abs(ball.vy);
        ball.vy = -Math.abs(ball.vy) * (0.74 * game.activeModifier.ballBounce);
        ball.vx *= 0.985;
        game.shake = Math.max(game.shake, clamp(impact / 90, 2, 10));
        pushBurst(game, ball.x, FLOOR_Y + 2, "rgba(255,255,255,0.9)", 7, 20, 120, 0.25, Math.PI, 0);
      } else {
        ball.vy = 0;
      }
    }

    if (ball.y - ball.r < CEILING_Y) {
      ball.y = CEILING_Y + ball.r;
      ball.vy = Math.abs(ball.vy) * 0.82;
      game.shake = Math.max(game.shake, 2);
    }

    if (ball.x - ball.r < 24) {
      ball.x = 24 + ball.r;
      ball.vx = Math.abs(ball.vx) * 0.86 * game.activeModifier.ballBounce;
      game.shake = Math.max(game.shake, 3);
    }

    if (ball.x + ball.r > WORLD_WIDTH - 24) {
      ball.x = WORLD_WIDTH - 24 - ball.r;
      ball.vx = -Math.abs(ball.vx) * 0.86 * game.activeModifier.ballBounce;
      game.shake = Math.max(game.shake, 3);
    }

    resolveHoopCollisions(ball, 0.92 * game.activeModifier.ballBounce);

    if (Math.hypot(ball.vx, ball.vy) > 90) {
      ball.trail.unshift({ x: ball.x, y: ball.y, life: 0.28 });
    }

    ball.trail = ball.trail
      .map((point) => ({ ...point, life: point.life - dt }))
      .filter((point) => point.life > 0)
      .slice(0, 12);
  };

  const interactBallWithPlayers = (game: GameState) => {
    const ball = game.ball;
    if (ball.heldBy !== null) {
      return;
    }

    let catcher: Player | null = null;
    let bestDistance = Number.POSITIVE_INFINITY;

    game.players.forEach((player) => {
      const dx = ball.x - player.x;
      const dy = ball.y - (player.y - 14);
      const dist = Math.hypot(dx, dy) || 0.0001;
      const minDistance = ball.r + player.r;

      if (dist < minDistance) {
        const nx = dx / dist;
        const ny = dy / dist;
        const overlap = minDistance - dist;
        ball.x += nx * overlap;
        ball.y += ny * overlap;

        const relativeVelocityX = ball.vx - player.vx;
        const relativeVelocityY = ball.vy - player.vy;
        const velocityAlongNormal = relativeVelocityX * nx + relativeVelocityY * ny;
        if (velocityAlongNormal < 0) {
          ball.vx -= (1 + 0.86 * game.activeModifier.ballBounce) * velocityAlongNormal * nx;
          ball.vy -= (1 + 0.86 * game.activeModifier.ballBounce) * velocityAlongNormal * ny;
        }
      }

      const catchRange = 46 + game.activeModifier.catchBonus;
      const canCatch =
        ball.catchCooldown <= 0 &&
        player.actionCooldown <= 0.12 &&
        Math.abs(ball.x - player.x) < catchRange &&
        ball.y > player.y - 64 &&
        ball.y < player.y + 12 &&
        Math.hypot(ball.vx, ball.vy) < 340;

      if (canCatch) {
        const currentDistance = distance(player.x, player.y - 12, ball.x, ball.y);
        if (currentDistance < bestDistance) {
          bestDistance = currentDistance;
          catcher = player;
        }
      }
    });

    if (catcher) {
      catchLooseBall(game, catcher);
    }
  };

  const checkScore = (game: GameState) => {
    const ball = game.ball;
    if (ball.scoreCooldown > 0 || ball.heldBy !== null) {
      return;
    }

    const crossedRightHoop =
      ball.prevY < RIGHT_HOOP.rimY &&
      ball.y >= RIGHT_HOOP.rimY &&
      ball.x > RIGHT_HOOP.rimX - 23 &&
      ball.x < RIGHT_HOOP.rimX + 23;

    const crossedLeftHoop =
      ball.prevY < LEFT_HOOP.rimY &&
      ball.y >= LEFT_HOOP.rimY &&
      ball.x > LEFT_HOOP.rimX - 23 &&
      ball.x < LEFT_HOOP.rimX + 23;

    if (crossedRightHoop) {
      scorePoint(game, 1);
    } else if (crossedLeftHoop) {
      scorePoint(game, 2);
    }
  };

  const updateParticles = (game: GameState, dt: number) => {
    game.particles = game.particles.filter((particle) => particle.life > 0);
    game.particles.forEach((particle) => {
      particle.life -= dt;
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vx *= 0.985;
      particle.vy += 420 * dt;
    });
  };

  const consumeInputs = () => {
    inputsRef.current.p1.jumpPressed = false;
    inputsRef.current.p1.actionPressed = false;
    inputsRef.current.p2.jumpPressed = false;
    inputsRef.current.p2.actionPressed = false;
  };

  const updateGame = (dt: number) => {
    const game = gameRef.current;
    game.shake = Math.max(0, game.shake - dt * 24);
    updateParticles(game, dt);

    if (game.phase === "start" || game.phase === "paused" || game.phase === "gameover") {
      consumeInputs();
      return;
    }

    if (game.phase === "round") {
      game.roundTimer -= dt;
      if (game.roundTimer <= 0) {
        game.phase = "playing";
        syncHud(game);
      }
      consumeInputs();
      return;
    }

    game.elapsed += dt;

    updatePlayer(game, game.players[0], inputsRef.current.p1, dt);
    updatePlayer(game, game.players[1], inputsRef.current.p2, dt);
    collidePlayers(game.players[0], game.players[1]);

    if (game.ball.heldBy !== null) {
      updateHeldBall(game, dt);
    } else {
      updateLooseBall(game, dt);
      interactBallWithPlayers(game);
      checkScore(game);
    }

    consumeInputs();
  };

  const drawCourtBackdrop = (ctx: CanvasRenderingContext2D, game: GameState) => {
    const sky = ctx.createLinearGradient(0, 0, 0, FLOOR_Y + 80);
    sky.addColorStop(0, "#07111f");
    sky.addColorStop(0.42, "#23124d");
    sky.addColorStop(0.78, "#7c2d12");
    sky.addColorStop(1, "#f97316");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);

    const sun = ctx.createRadialGradient(WORLD_WIDTH / 2, 122, 18, WORLD_WIDTH / 2, 122, 190);
    sun.addColorStop(0, "rgba(253,186,116,0.95)");
    sun.addColorStop(0.35, "rgba(251,146,60,0.55)");
    sun.addColorStop(1, "rgba(251,146,60,0)");
    ctx.fillStyle = sun;
    ctx.beginPath();
    ctx.arc(WORLD_WIDTH / 2, 122, 190, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "rgba(255,255,255,0.08)";
    for (let index = 0; index < 12; index += 1) {
      ctx.fillRect(54 + index * 78, 116 + (index % 2) * 10, 42, 4);
    }

    ctx.fillStyle = "rgba(10, 14, 30, 0.48)";
    ctx.fillRect(0, 188, WORLD_WIDTH, 96);

    for (let index = 0; index < 60; index += 1) {
      const x = 12 + index * 17;
      const height = 14 + (index % 4) * 10;
      ctx.beginPath();
      ctx.arc(x, 232 - height, 8 + (index % 3), 0, Math.PI * 2);
      ctx.fill();
      ctx.fillRect(x - 7, 232 - height + 8, 14, 20 + (index % 5) * 4);
    }

    const court = ctx.createLinearGradient(0, 300, 0, WORLD_HEIGHT);
    court.addColorStop(0, "#fbbf24");
    court.addColorStop(0.45, "#fb923c");
    court.addColorStop(1, "#7c2d12");
    ctx.fillStyle = court;
    ctx.fillRect(0, 300, WORLD_WIDTH, WORLD_HEIGHT - 300);

    const gloss = ctx.createLinearGradient(0, 300, WORLD_WIDTH, WORLD_HEIGHT);
    gloss.addColorStop(0, "rgba(255,255,255,0.22)");
    gloss.addColorStop(0.3, "rgba(255,255,255,0)");
    gloss.addColorStop(0.7, "rgba(255,255,255,0.08)");
    gloss.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = gloss;
    ctx.fillRect(0, 300, WORLD_WIDTH, WORLD_HEIGHT - 300);

    ctx.strokeStyle = "rgba(255,244,214,0.8)";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(0, FLOOR_Y + 1);
    ctx.lineTo(WORLD_WIDTH, FLOOR_Y + 1);
    ctx.stroke();

    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(WORLD_WIDTH / 2, 300);
    ctx.lineTo(WORLD_WIDTH / 2, FLOOR_Y);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(WORLD_WIDTH / 2, 392, 56, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeRect(48, 332, 132, 150);
    ctx.strokeRect(WORLD_WIDTH - 180, 332, 132, 150);

    ctx.beginPath();
    ctx.arc(180, 392, 56, -Math.PI / 2, Math.PI / 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(WORLD_WIDTH - 180, 392, 56, Math.PI / 2, (Math.PI * 3) / 2);
    ctx.stroke();

    const bannerAlpha = 0.12 + Math.sin(game.elapsed * 2) * 0.03;
    ctx.fillStyle = `rgba(255,255,255,${bannerAlpha})`;
    roundedRect(ctx, 340, 36, 320, 44, 22);
    ctx.fill();
  };

  const drawHoop = (ctx: CanvasRenderingContext2D, hoop: typeof LEFT_HOOP, mirror: boolean) => {
    ctx.strokeStyle = "rgba(255,255,255,0.75)";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(mirror ? hoop.boardX + hoop.boardW : hoop.boardX, hoop.boardY + 18);
    ctx.lineTo(mirror ? hoop.boardX + 100 : hoop.boardX - 100, hoop.boardY + 48);
    ctx.stroke();

    ctx.fillStyle = "rgba(225, 240, 255, 0.34)";
    ctx.strokeStyle = "rgba(255,255,255,0.95)";
    ctx.lineWidth = 4;
    roundedRect(ctx, hoop.boardX, hoop.boardY, hoop.boardW, hoop.boardH, 5);
    ctx.fill();
    ctx.stroke();

    ctx.strokeStyle = "#f97316";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(hoop.rimX - 24, hoop.rimY);
    ctx.lineTo(hoop.rimX + 24, hoop.rimY);
    ctx.stroke();

    ctx.fillStyle = "#fb923c";
    ctx.beginPath();
    ctx.arc(hoop.rimX - 24, hoop.rimY, 8, 0, Math.PI * 2);
    ctx.arc(hoop.rimX + 24, hoop.rimY, 8, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "rgba(255,255,255,0.68)";
    ctx.lineWidth = 2;
    for (let index = 0; index < 6; index += 1) {
      const t = index / 5;
      const x = hoop.rimX - 18 + t * 36;
      ctx.beginPath();
      ctx.moveTo(x, hoop.rimY + 2);
      ctx.lineTo(hoop.rimX - 12 + t * 24, hoop.rimY + 28);
      ctx.stroke();
    }

    ctx.beginPath();
    ctx.moveTo(hoop.rimX - 16, hoop.rimY + 10);
    ctx.bezierCurveTo(hoop.rimX - 12, hoop.rimY + 28, hoop.rimX + 12, hoop.rimY + 28, hoop.rimX + 16, hoop.rimY + 10);
    ctx.stroke();
  };

  const drawShadow = (ctx: CanvasRenderingContext2D, x: number, y: number, width: number, alpha: number) => {
    const shadow = ctx.createRadialGradient(x, y, 8, x, y, width);
    shadow.addColorStop(0, `rgba(15, 23, 42, ${alpha})`);
    shadow.addColorStop(1, "rgba(15, 23, 42, 0)");
    ctx.fillStyle = shadow;
    ctx.beginPath();
    ctx.ellipse(x, y, width, width * 0.32, 0, 0, Math.PI * 2);
    ctx.fill();
  };

  const drawPlayer = (ctx: CanvasRenderingContext2D, player: Player, time: number) => {
    drawShadow(ctx, player.x, FLOOR_Y + 6, 34 + Math.abs(player.vx) * 0.04, 0.34);

    const runWave = Math.sin(time * 11 + player.x * 0.03) * Math.min(1, Math.abs(player.vx) / 180);
    const stretch = clamp(player.vy * 0.00022, -0.13, 0.16);
    const squashBoost = player.squash * 0.14;

    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.scale(1 + squashBoost - stretch * 0.6, 1 - squashBoost + stretch);

    ctx.strokeStyle = "rgba(255,255,255,0.8)";
    ctx.lineWidth = 6;
    ctx.lineCap = "round";

    ctx.beginPath();
    ctx.moveTo(-8, 12);
    ctx.lineTo(-10 - runWave * 8, 32);
    ctx.moveTo(8, 12);
    ctx.lineTo(10 + runWave * 8, 32);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-12, -6);
    ctx.lineTo(-24 + runWave * 8, 8);
    ctx.moveTo(12, -6);
    ctx.lineTo(22 - runWave * 4, 10);
    ctx.stroke();

    ctx.shadowColor = player.flash > 0 ? player.accent : "transparent";
    ctx.shadowBlur = player.flash > 0 ? 16 : 0;
    ctx.fillStyle = player.color;
    ctx.beginPath();
    ctx.arc(0, 0, player.r, 0, Math.PI * 2);
    ctx.fill();

    const highlight = ctx.createLinearGradient(-24, -28, 18, 24);
    highlight.addColorStop(0, "rgba(255,255,255,0.48)");
    highlight.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = highlight;
    ctx.beginPath();
    ctx.arc(-6, -8, player.r * 0.82, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "rgba(15,23,42,0.92)";
    ctx.beginPath();
    ctx.arc(player.dir * 7, -4, 4.2, 0, Math.PI * 2);
    ctx.arc(player.dir * 12, -4, 4.2, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "rgba(15,23,42,0.9)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(player.dir * 8, 7, 8, 0.2, Math.PI - 0.2);
    ctx.stroke();

    ctx.fillStyle = player.accent;
    roundedRect(ctx, -16, 6, 32, 10, 5);
    ctx.fill();

    ctx.fillStyle = "rgba(255,255,255,0.95)";
    ctx.font = "900 11px Inter, system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(player.id === 1 ? "P1" : "P2", 0, 10);
    ctx.restore();
  };

  const drawBall = (ctx: CanvasRenderingContext2D, ball: Ball) => {
    ball.trail.forEach((point, index) => {
      const alpha = point.life * 0.45 * (1 - index / Math.max(ball.trail.length, 1));
      ctx.fillStyle = `rgba(251, 146, 60, ${alpha})`;
      ctx.beginPath();
      ctx.arc(point.x, point.y, Math.max(4, ball.r - index * 0.35), 0, Math.PI * 2);
      ctx.fill();
    });

    drawShadow(ctx, ball.x, FLOOR_Y + 8, 20 + Math.abs(ball.vy) * 0.02, 0.24);

    ctx.save();
    ctx.translate(ball.x, ball.y);
    ctx.rotate(ball.spin);
    ctx.shadowColor = ball.flash > 0 ? "#fde68a" : "transparent";
    ctx.shadowBlur = ball.flash > 0 ? 18 : 0;
    ctx.fillStyle = "#f97316";
    ctx.beginPath();
    ctx.arc(0, 0, ball.r, 0, Math.PI * 2);
    ctx.fill();

    const gloss = ctx.createRadialGradient(-ball.r * 0.45, -ball.r * 0.55, 1, 0, 0, ball.r * 1.1);
    gloss.addColorStop(0, "rgba(255,255,255,0.55)");
    gloss.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = gloss;
    ctx.beginPath();
    ctx.arc(-ball.r * 0.2, -ball.r * 0.2, ball.r * 0.82, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = "rgba(90, 31, 8, 0.9)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, ball.r * 0.96, Math.PI * 0.2, Math.PI * 1.8);
    ctx.moveTo(-ball.r, 0);
    ctx.quadraticCurveTo(0, ball.r * 0.9, ball.r, 0);
    ctx.moveTo(-ball.r, 0);
    ctx.quadraticCurveTo(0, -ball.r * 0.9, ball.r, 0);
    ctx.stroke();
    ctx.restore();
  };

  const drawParticles = (ctx: CanvasRenderingContext2D, particles: Particle[]) => {
    particles.forEach((particle) => {
      const alpha = clamp(particle.life / particle.maxLife, 0, 1);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.translate(particle.x, particle.y);
      ctx.fillStyle = particle.color;
      ctx.strokeStyle = particle.color;
      ctx.lineWidth = 2;

      if (particle.shape === "spark") {
        ctx.beginPath();
        ctx.moveTo(-particle.size, 0);
        ctx.lineTo(particle.size, 0);
        ctx.moveTo(0, -particle.size);
        ctx.lineTo(0, particle.size);
        ctx.stroke();
      } else if (particle.shape === "star") {
        ctx.rotate(alpha * 2.4);
        ctx.beginPath();
        for (let point = 0; point < 5; point += 1) {
          const outerAngle = (point / 5) * Math.PI * 2 - Math.PI / 2;
          const innerAngle = outerAngle + Math.PI / 5;
          const outerRadius = particle.size;
          const innerRadius = particle.size * 0.45;
          if (point === 0) {
            ctx.moveTo(Math.cos(outerAngle) * outerRadius, Math.sin(outerAngle) * outerRadius);
          } else {
            ctx.lineTo(Math.cos(outerAngle) * outerRadius, Math.sin(outerAngle) * outerRadius);
          }
          ctx.lineTo(Math.cos(innerAngle) * innerRadius, Math.sin(innerAngle) * innerRadius);
        }
        ctx.closePath();
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, particle.size * alpha, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    });
  };

  const drawScoreBadge = (
    ctx: CanvasRenderingContext2D,
    x: number,
    label: string,
    score: number,
    color: string,
    align: CanvasTextAlign,
  ) => {
    ctx.save();
    const width = 132;
    const originX = align === "left" ? x : x - width;
    ctx.fillStyle = "rgba(10,14,32,0.5)";
    ctx.strokeStyle = `${color}88`;
    ctx.lineWidth = 2;
    roundedRect(ctx, originX, 32, width, 72, 24);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.font = "700 13px Inter, system-ui, sans-serif";
    ctx.textAlign = align;
    ctx.fillText(label, align === "left" ? x + 18 : x - 18, 58);

    ctx.fillStyle = color;
    ctx.font = "900 34px Inter, system-ui, sans-serif";
    ctx.fillText(String(score), align === "left" ? x + 18 : x - 18, 88);
    ctx.restore();
  };

  const drawCenterStatus = (ctx: CanvasRenderingContext2D, game: GameState) => {
    ctx.save();
    ctx.fillStyle = "rgba(255,255,255,0.95)";
    ctx.textAlign = "center";
    ctx.font = "900 18px Inter, system-ui, sans-serif";
    ctx.fillText(game.activeModifier.name.toUpperCase(), WORLD_WIDTH / 2, 64);
    ctx.font = "600 12px Inter, system-ui, sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.72)";
    ctx.fillText(game.activeModifier.blurb, WORLD_WIDTH / 2, 84);

    if (game.phase === "round") {
      ctx.fillStyle = "rgba(255,255,255,0.98)";
      ctx.font = "900 26px Inter, system-ui, sans-serif";
      ctx.fillText(game.roundMessage, WORLD_WIDTH / 2, 126);
      ctx.font = "700 16px Inter, system-ui, sans-serif";
      ctx.fillStyle = "rgba(255,255,255,0.8)";
      ctx.fillText(`Tip-off in ${Math.max(1, Math.ceil(game.roundTimer))}`, WORLD_WIDTH / 2, 150);
    }

    ctx.restore();
  };

  const drawScene = () => {
    const canvas = canvasRef.current;
    const game = gameRef.current;
    const viewport = viewportRef.current;
    if (!canvas || viewport.width <= 0 || viewport.height <= 0) {
      return;
    }

    const context = canvas.getContext("2d");
    if (!context) {
      return;
    }

    const { width, height, dpr } = viewport;
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.scale(dpr, dpr);

    const scale = Math.min(width / WORLD_WIDTH, height / WORLD_HEIGHT);
    const offsetX = (width - WORLD_WIDTH * scale) / 2;
    const offsetY = (height - WORLD_HEIGHT * scale) / 2;
    const shakeX = game.shake > 0 ? (Math.random() - 0.5) * game.shake : 0;
    const shakeY = game.shake > 0 ? (Math.random() - 0.5) * game.shake : 0;

    const bg = context.createLinearGradient(0, 0, width, height);
    bg.addColorStop(0, "#020617");
    bg.addColorStop(0.45, "#111827");
    bg.addColorStop(1, "#1e1b4b");
    context.fillStyle = bg;
    context.fillRect(0, 0, width, height);

    context.save();
    context.translate(offsetX, offsetY);
    context.scale(scale, scale);
    context.translate(shakeX, shakeY);

    drawCourtBackdrop(context, game);
    drawHoop(context, LEFT_HOOP, false);
    drawHoop(context, RIGHT_HOOP, true);
    drawParticles(context, game.particles.filter((particle) => particle.shape === "circle"));
    drawPlayer(context, game.players[0], game.elapsed);
    drawPlayer(context, game.players[1], game.elapsed);
    drawBall(context, game.ball);
    drawParticles(context, game.particles.filter((particle) => particle.shape !== "circle"));
    drawScoreBadge(context, 32, "PLAYER 1", game.score1, "#f59e0b", "left");
    drawScoreBadge(context, WORLD_WIDTH - 32, "PLAYER 2", game.score2, "#67e8f9", "right");
    drawCenterStatus(context, game);

    if (game.phase === "paused") {
      context.fillStyle = "rgba(2,6,23,0.52)";
      context.fillRect(0, 0, WORLD_WIDTH, WORLD_HEIGHT);
      context.fillStyle = "rgba(255,255,255,0.98)";
      context.font = "900 42px Inter, system-ui, sans-serif";
      context.textAlign = "center";
      context.fillText("PAUSED", WORLD_WIDTH / 2, WORLD_HEIGHT / 2 - 8);
      context.font = "600 16px Inter, system-ui, sans-serif";
      context.fillStyle = "rgba(255,255,255,0.78)";
      context.fillText("Press P or tap Resume to get back on court.", WORLD_WIDTH / 2, WORLD_HEIGHT / 2 + 28);
    }

    context.restore();
  };

  const togglePause = () => {
    const game = gameRef.current;
    if (game.phase === "playing") {
      game.phase = "paused";
      syncHud(game);
      clearInputs();
    } else if (game.phase === "paused") {
      game.phase = "playing";
      syncHud(game);
    }
  };

  useEffect(() => {
    setHighScores(loadHighScores());
  }, []);

  useEffect(() => {
    const resize = () => {
      const canvas = canvasRef.current;
      const stage = stageRef.current;
      if (!canvas || !stage) {
        return;
      }

      const rect = stage.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      viewportRef.current = {
        width: rect.width,
        height: rect.height,
        dpr,
      };
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      drawScene();
    };

    resize();

    const observer = new ResizeObserver(resize);
    if (stageRef.current) {
      observer.observe(stageRef.current);
    }

    window.addEventListener("resize", resize);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", resize);
    };
  }, []);

  useEffect(() => {
    const preventKeys = new Set([
      "KeyA",
      "KeyD",
      "KeyW",
      "KeyF",
      "ArrowLeft",
      "ArrowRight",
      "ArrowUp",
      "Slash",
      "KeyP",
      "Escape",
      "Enter",
      "Space",
      "KeyR",
    ]);

    const keyMap: Record<string, ["p1" | "p2", "left" | "right" | "jump" | "action"]> = {
      KeyA: ["p1", "left"],
      KeyD: ["p1", "right"],
      KeyW: ["p1", "jump"],
      KeyF: ["p1", "action"],
      ArrowLeft: ["p2", "left"],
      ArrowRight: ["p2", "right"],
      ArrowUp: ["p2", "jump"],
      Slash: ["p2", "action"],
    };

    const launchKeys = new Set(["Enter", "Space", "KeyW", "KeyF", "ArrowUp", "Slash"]);

    const onKeyDown = (event: KeyboardEvent) => {
      if (preventKeys.has(event.code)) {
        event.preventDefault();
      }

      const game = gameRef.current;

      if (event.code === "KeyP" || event.code === "Escape") {
        if (!event.repeat && (game.phase === "playing" || game.phase === "paused")) {
          togglePause();
        }
        return;
      }

      if (event.code === "KeyR") {
        if (!event.repeat) {
          startMatch();
        }
        return;
      }

      if (game.phase === "start" && launchKeys.has(event.code)) {
        if (!event.repeat) {
          startMatch();
        }
        return;
      }

      if (game.phase === "gameover" && launchKeys.has(event.code)) {
        if (!event.repeat) {
          startMatch();
        }
        return;
      }

      if (game.phase !== "playing") {
        return;
      }

      const binding = keyMap[event.code];
      if (!binding) {
        return;
      }

      const [playerKey, control] = binding;
      setControlState(playerKey, control, true);
    };

    const onKeyUp = (event: KeyboardEvent) => {
      const binding = keyMap[event.code];
      if (!binding) {
        return;
      }

      const [playerKey, control] = binding;
      setControlState(playerKey, control, false);
    };

    const onBlur = () => clearInputs();

    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);

    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
    };
  }, []);

  useEffect(() => {
    const frame = (time: number) => {
      const delta = lastTimeRef.current ? Math.min(0.022, (time - lastTimeRef.current) / 1000) : 1 / 60;
      lastTimeRef.current = time;
      updateGame(delta);
      drawScene();
      frameRef.current = window.requestAnimationFrame(frame);
    };

    frameRef.current = window.requestAnimationFrame(frame);

    return () => {
      if (frameRef.current !== null) {
        window.cancelAnimationFrame(frameRef.current);
      }
    };
  }, []);

  const setTouchControl = (
    key: string,
    playerKey: "p1" | "p2",
    control: "left" | "right" | "jump" | "action",
    active: boolean,
  ) => {
    const phase = gameRef.current.phase;
    if (phase === "start" || phase === "gameover") {
      if (active) {
        startMatch();
      }
      return;
    }

    if (phase !== "playing") {
      return;
    }

    setTouchPressed((current) => ({ ...current, [key]: active }));
    setControlState(playerKey, control, active);
  };

  const scoreboard = `${hud.score1} - ${hud.score2}`;

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(59,130,246,0.12),_transparent_34%),linear-gradient(180deg,_#020617_0%,_#0f172a_48%,_#111827_100%)] px-3 py-3 text-white sm:px-5 sm:py-5">
      <div className="mx-auto flex min-h-[calc(100vh-1.5rem)] w-full max-w-[1500px] flex-col gap-3 sm:min-h-[calc(100vh-2.5rem)] sm:gap-5">
        <header className="flex flex-col gap-3 rounded-[2rem] border border-white/10 bg-white/6 px-4 py-4 shadow-[0_20px_60px_rgba(2,6,23,0.45)] backdrop-blur-xl sm:px-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.35em] text-orange-200/80">Arcade local versus</p>
              <h1 className="mt-1 text-3xl font-black tracking-tight text-white sm:text-4xl">Neon Rim Rumble</h1>
              <p className="mt-2 max-w-2xl text-sm text-slate-300 sm:text-base">
                Funny physics, fast rebounds, instant dunks, blocks, steals, random round twists, and couch-competitive chaos.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="rounded-full border border-white/10 bg-slate-950/50 px-4 py-2 text-sm font-semibold text-slate-100">
                First to {SCORE_TO_WIN}
              </div>
              <div className="rounded-full border border-amber-300/25 bg-amber-400/10 px-4 py-2 text-sm font-semibold text-amber-100">
                {hud.modifierName}
              </div>
              <button
                type="button"
                className="rounded-full border border-cyan-300/25 bg-cyan-400/12 px-4 py-2 text-sm font-semibold text-cyan-100 transition hover:-translate-y-0.5 hover:bg-cyan-400/18"
                onClick={togglePause}
              >
                {hud.phase === "paused" ? "Resume" : "Pause"}
              </button>
              <button
                type="button"
                className="rounded-full border border-fuchsia-300/25 bg-fuchsia-400/12 px-4 py-2 text-sm font-semibold text-fuchsia-100 transition hover:-translate-y-0.5 hover:bg-fuchsia-400/18"
                onClick={startMatch}
              >
                Instant restart
              </button>
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-[1fr_auto_1fr] md:items-center">
            <div className="rounded-[1.4rem] border border-violet-300/20 bg-violet-500/10 px-4 py-3">
              <div className="text-[10px] font-bold uppercase tracking-[0.28em] text-violet-200/80">Player 1</div>
              <div className="mt-1 text-sm font-medium text-violet-50">{CONTROL_HINTS.p1}</div>
            </div>
            <div className="rounded-[1.4rem] border border-white/10 bg-slate-950/45 px-5 py-3 text-center">
              <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-slate-400">Score</div>
              <div className="mt-1 text-3xl font-black tracking-[0.18em] text-white">{scoreboard}</div>
            </div>
            <div className="rounded-[1.4rem] border border-cyan-300/20 bg-cyan-500/10 px-4 py-3 md:text-right">
              <div className="text-[10px] font-bold uppercase tracking-[0.28em] text-cyan-200/80">Player 2</div>
              <div className="mt-1 text-sm font-medium text-cyan-50">{CONTROL_HINTS.p2}</div>
            </div>
          </div>
        </header>

        <div className="grid flex-1 gap-3 xl:grid-cols-[minmax(0,1fr)_320px] xl:gap-5">
          <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-slate-950/40 shadow-[0_30px_70px_rgba(2,6,23,0.5)] backdrop-blur-sm">
            <div ref={stageRef} className="relative aspect-[16/10] min-h-[55svh] w-full bg-transparent xl:min-h-full">
              <canvas ref={canvasRef} className="block h-full w-full" />

              {hud.phase === "start" && (
                <div className="absolute inset-0 z-20 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-md">
                  <div className="max-w-3xl rounded-[2rem] border border-white/10 bg-white/8 p-5 text-center shadow-[0_24px_70px_rgba(2,6,23,0.42)] sm:p-8">
                    <p className="text-xs font-bold uppercase tracking-[0.38em] text-orange-200/80">Playable in under 10 seconds</p>
                    <h2 className="mt-3 text-4xl font-black tracking-tight text-white sm:text-6xl">Tip off the chaos.</h2>
                    <p className="mx-auto mt-4 max-w-2xl text-sm text-slate-200 sm:text-base">
                      Race for dunks, launch wild bank shots, spike blocks, and rip steals while the court mutates every round.
                    </p>
                    <div className="mt-6 grid gap-3 text-left sm:grid-cols-2">
                      <div className="rounded-[1.4rem] border border-violet-300/20 bg-violet-500/10 p-4">
                        <div className="text-sm font-bold uppercase tracking-[0.24em] text-violet-100">Player 1</div>
                        <div className="mt-2 text-sm text-violet-50">W jump, A/D move, F shoot • dunk • block • steal.</div>
                      </div>
                      <div className="rounded-[1.4rem] border border-cyan-300/20 bg-cyan-500/10 p-4">
                        <div className="text-sm font-bold uppercase tracking-[0.24em] text-cyan-100">Player 2</div>
                        <div className="mt-2 text-sm text-cyan-50">↑ jump, ←/→ move, / shoot • dunk • block • steal.</div>
                      </div>
                    </div>
                    <div className="mt-6 flex flex-col items-center justify-center gap-3 sm:flex-row">
                      <button
                        type="button"
                        className="rounded-full border border-amber-200/30 bg-gradient-to-r from-orange-400 via-amber-300 to-pink-300 px-6 py-3 text-sm font-black uppercase tracking-[0.28em] text-slate-950 transition hover:-translate-y-0.5"
                        onClick={startMatch}
                      >
                        Start match
                      </button>
                      <div className="rounded-full border border-white/10 bg-slate-950/55 px-5 py-3 text-sm text-slate-200">
                        Or tap any touch control / press jump or action to launch.
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {hud.phase === "paused" && (
                <div className="absolute inset-0 z-20 flex items-center justify-center bg-slate-950/55 p-4 backdrop-blur-sm">
                  <div className="rounded-[2rem] border border-white/10 bg-slate-950/80 px-8 py-7 text-center shadow-[0_24px_70px_rgba(2,6,23,0.45)]">
                    <div className="text-xs font-bold uppercase tracking-[0.34em] text-slate-300">Game paused</div>
                    <div className="mt-2 text-4xl font-black text-white">Catch your breath.</div>
                    <p className="mt-3 max-w-md text-sm text-slate-300">Press P, Escape, or tap Resume. Press R anytime for an instant new match.</p>
                    <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                      <button
                        type="button"
                        className="rounded-full border border-cyan-200/30 bg-cyan-400/15 px-5 py-3 text-sm font-bold text-cyan-50 transition hover:-translate-y-0.5"
                        onClick={togglePause}
                      >
                        Resume
                      </button>
                      <button
                        type="button"
                        className="rounded-full border border-fuchsia-200/30 bg-fuchsia-400/15 px-5 py-3 text-sm font-bold text-fuchsia-50 transition hover:-translate-y-0.5"
                        onClick={startMatch}
                      >
                        Restart now
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {hud.phase === "gameover" && (
                <div className="absolute inset-0 z-20 flex items-center justify-center bg-slate-950/65 p-4 backdrop-blur-md">
                  <div className="max-w-2xl rounded-[2rem] border border-white/10 bg-white/8 p-6 text-center shadow-[0_24px_70px_rgba(2,6,23,0.5)] sm:p-8">
                    <div className="text-xs font-bold uppercase tracking-[0.36em] text-amber-200/80">Game over</div>
                    <h2 className="mt-2 text-4xl font-black text-white sm:text-5xl">{hud.winnerText}</h2>
                    <p className="mt-3 text-lg font-semibold text-slate-100">Final score: {scoreboard}</p>
                    <p className="mt-2 text-sm text-slate-300">Match time: {formatTime(Math.round(gameRef.current.elapsed * 1000))}</p>
                    {freshRecord && (
                      <div className="mt-4 inline-flex rounded-full border border-emerald-200/30 bg-emerald-400/15 px-4 py-2 text-sm font-bold text-emerald-100">
                        New fastest local victory!
                      </div>
                    )}
                    <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                      <button
                        type="button"
                        className="rounded-full border border-amber-200/30 bg-gradient-to-r from-orange-400 via-amber-300 to-pink-300 px-6 py-3 text-sm font-black uppercase tracking-[0.28em] text-slate-950 transition hover:-translate-y-0.5"
                        onClick={startMatch}
                      >
                        Rematch instantly
                      </button>
                      <div className="rounded-full border border-white/10 bg-slate-950/55 px-5 py-3 text-sm text-slate-200">Press R, Enter, or tap a control to restart.</div>
                    </div>
                  </div>
                </div>
              )}

              <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex justify-center p-3 sm:p-5">
                <div className="rounded-full border border-white/10 bg-slate-950/55 px-4 py-2 text-center shadow-[0_10px_24px_rgba(2,6,23,0.35)] backdrop-blur-md">
                  <div className="text-[10px] font-bold uppercase tracking-[0.28em] text-slate-400">Round modifier</div>
                  <div className="text-sm font-black text-white sm:text-base">{hud.modifierName}</div>
                  <div className="hidden text-xs text-slate-300 sm:block">{hud.modifierBlurb}</div>
                </div>
              </div>

              <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between gap-2 p-2 sm:p-4">
                <div className="pointer-events-auto grid w-[49%] grid-cols-[1.3fr,0.8fr,0.95fr] gap-2 rounded-[1.6rem] border border-white/10 bg-slate-950/35 p-2 backdrop-blur-md md:max-w-[440px]">
                  <div className="grid grid-cols-2 gap-2">
                    <ControlButton
                      active={!!touchPressed.p1Left}
                      label="◀"
                      caption="Move"
                      hue="violet"
                      onActiveChange={(active) => setTouchControl("p1Left", "p1", "left", active)}
                    />
                    <ControlButton
                      active={!!touchPressed.p1Right}
                      label="▶"
                      caption="Move"
                      hue="violet"
                      onActiveChange={(active) => setTouchControl("p1Right", "p1", "right", active)}
                    />
                  </div>
                  <ControlButton
                    active={!!touchPressed.p1Jump}
                    label="⤴"
                    caption="Jump"
                    hue="violet"
                    onActiveChange={(active) => setTouchControl("p1Jump", "p1", "jump", active)}
                  />
                  <ControlButton
                    active={!!touchPressed.p1Action}
                    label="✦"
                    caption="Act"
                    hue="violet"
                    onActiveChange={(active) => setTouchControl("p1Action", "p1", "action", active)}
                  />
                </div>

                <div className="pointer-events-auto grid w-[49%] grid-cols-[0.95fr,0.8fr,1.3fr] gap-2 rounded-[1.6rem] border border-white/10 bg-slate-950/35 p-2 backdrop-blur-md md:max-w-[440px]">
                  <ControlButton
                    active={!!touchPressed.p2Action}
                    label="✦"
                    caption="Act"
                    hue="cyan"
                    onActiveChange={(active) => setTouchControl("p2Action", "p2", "action", active)}
                  />
                  <ControlButton
                    active={!!touchPressed.p2Jump}
                    label="⤴"
                    caption="Jump"
                    hue="cyan"
                    onActiveChange={(active) => setTouchControl("p2Jump", "p2", "jump", active)}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <ControlButton
                      active={!!touchPressed.p2Left}
                      label="◀"
                      caption="Move"
                      hue="cyan"
                      onActiveChange={(active) => setTouchControl("p2Left", "p2", "left", active)}
                    />
                    <ControlButton
                      active={!!touchPressed.p2Right}
                      label="▶"
                      caption="Move"
                      hue="cyan"
                      onActiveChange={(active) => setTouchControl("p2Right", "p2", "right", active)}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <aside className="flex flex-col gap-3 xl:gap-5">
            <section className="rounded-[2rem] border border-white/10 bg-white/6 p-5 shadow-[0_20px_60px_rgba(2,6,23,0.38)] backdrop-blur-xl">
              <div className="text-xs font-bold uppercase tracking-[0.34em] text-slate-400">How to win</div>
              <h3 className="mt-2 text-2xl font-black text-white">Fast, silly, readable basketball.</h3>
              <ul className="mt-4 space-y-3 text-sm text-slate-200">
                <li>• Action is context-sensitive: shoot if you have the ball, dunk if you are airborne near the rim, block loose shots, or steal from the ball carrier.</li>
                <li>• Every score changes the modifier, so the next point always feels different.</li>
                <li>• Pause with <span className="font-bold text-white">P</span> or <span className="font-bold text-white">Escape</span>. Restart instantly with <span className="font-bold text-white">R</span>.</li>
                <li>• The touch pads support simultaneous holds for mobile couch battles on one screen.</li>
              </ul>
            </section>

            <section className="rounded-[2rem] border border-white/10 bg-white/6 p-5 shadow-[0_20px_60px_rgba(2,6,23,0.38)] backdrop-blur-xl">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-bold uppercase tracking-[0.34em] text-slate-400">Local high-score table</div>
                  <h3 className="mt-2 text-2xl font-black text-white">Fastest victories</h3>
                </div>
                <div className="rounded-full border border-white/10 bg-slate-950/45 px-3 py-2 text-xs font-semibold text-slate-200">
                  Best of this browser
                </div>
              </div>

              <div className="mt-4 overflow-hidden rounded-[1.4rem] border border-white/10 bg-slate-950/45">
                <div className="grid grid-cols-[52px_1.1fr_auto] gap-3 border-b border-white/10 px-4 py-3 text-[11px] font-bold uppercase tracking-[0.28em] text-slate-400">
                  <div>Rank</div>
                  <div>Winner</div>
                  <div>Time</div>
                </div>

                {highScores.length === 0 ? (
                  <div className="px-4 py-6 text-sm text-slate-300">No local records yet. Finish a match to stamp the hall of fame.</div>
                ) : (
                  <div>
                    {highScores.map((entry, index) => (
                      <div
                        key={`${entry.createdAt}-${index}`}
                        className="grid grid-cols-[52px_1.1fr_auto] gap-3 border-b border-white/6 px-4 py-4 text-sm last:border-b-0"
                      >
                        <div className="font-black text-amber-200">#{index + 1}</div>
                        <div>
                          <div className="font-semibold text-white">{entry.winner}</div>
                          <div className="mt-1 text-xs text-slate-400">
                            {entry.score} • {entry.modifier} • {new Date(entry.createdAt).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="font-black text-cyan-200">{formatTime(entry.timeMs)}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </section>
          </aside>
        </div>
      </div>
    </div>
  );
}
